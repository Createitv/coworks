# Early survey — 2026-09-01

42 people replied to the launch survey. This is a response count, not the eligible pilot population or completion count.
