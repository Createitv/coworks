# Rollout decision — 2026-09-14

Expand only when at least 80% of eligible pilot employees complete the steps and completion evidence from a second team is available. Second-team results have not been collected.
